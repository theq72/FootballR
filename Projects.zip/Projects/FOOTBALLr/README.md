Welcome to FOOTBALLr

root\views contains our client-side pages using handlebars.

root\routes contains our server-side code using Node.js, MongoDB, Express, and socket.io.

app.js is our main server files containing all Node.js, MongoDB, Express and socket.io information.

Currently working on:
  1. Implement socket functionality for multiple host interaction.
  2. Finish our draft functionality.
  3. Improve CSS styling to make it pretty.
